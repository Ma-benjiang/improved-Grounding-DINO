from selenium import webdriver
from lxml import etree
import time
import requests
import os
import csv


class Text(object):
    def __init__(self):
        self.driver = webdriver.Chrome()
        self.header = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.80 Safari/537.36'}
        chrome_opt = webdriver.ChromeOptions()
        # chrome_opt.add_argument("--headless")
        chrome_opt.add_argument(
            'user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36')
        prefs = {
            "profile.managed_default_content_settings.images": 2
        }

        chrome_opt.add_argument("--disable-blink-features=AutomationControlled")

        chrome_opt.add_experimental_option("prefs", prefs)
        # 创建chrome无界面对象 options=chrome_opt
        self.driver = webdriver.Chrome(options=chrome_opt)

    def __del__(self):
        self.driver.quit()

    def run(self, url):
        self.driver.get(url)
        time.sleep(3)

        self.driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")
        res = etree.HTML(self.driver.page_source)
        hrefs = res.xpath("//img[@class='ltr-1w2up3s']/@src")
        open("./farfetch_urls3.txt", "a").writelines('\n'.join(hrefs))
        return hrefs

    def download(self, hrefs, file_path):
        index = 0
        for url in hrefs:
            r = requests.get(url, headers=self.header)
            time.sleep(1)
            with open(file_path + f"1-{index}.png", 'wb') as f:
                f.write(r.content)
            index += 1

    def get_all_imge(self,count):

        # 打开CSV文件
        with open('url2.csv') as csv_file:
            # 创建CSV读取器
            csv_reader = csv.reader(csv_file)

            # 遍历CSV文件每一行
            for row in csv_reader:
                # 输出第一列
                try:
                    url = row[0]
                    hrefs = self.run(url)
                    count += 1
                    os.makedirs(f"./data2/{count}/", exist_ok=True)
                    page = self.driver.page_source
                    with open(f"./data2/{count}/page_source.txt", "w", encoding="utf-8") as f:
                        f.write(page)
                    self.download(hrefs, f"./data2/{count}/")

                except:
                    continue
        return count


if __name__ == '__main__':
    a = Text()
    count = 0
    a.get_all_imge(count)